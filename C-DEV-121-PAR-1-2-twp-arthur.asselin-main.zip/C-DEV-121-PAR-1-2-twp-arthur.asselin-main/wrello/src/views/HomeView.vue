<script setup>
import TheWelcome from '../components/TheWelcome.vue'

import CatList from '../components/Lists.vue'
</script>

<template>
  <main>
 
   <CatList />
  </main>
</template>
