<script setup>
 import Card from '../components/CardsUnit.vue'
 import comments from '../components/CommentList.vue'
</script>


<template>
  <div class="card">
    <Card />
    <comments />
  </div>
</template>


<style>

</style>
